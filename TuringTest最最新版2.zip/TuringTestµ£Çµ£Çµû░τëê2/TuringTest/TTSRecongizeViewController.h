//
//  TTSRecongizeViewController.h
//  TuringTest
//
//  Created by Turing on 15/8/31.
//  Copyright (c) 2015年 Turing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTSRecongizeViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *recognizeResultTextView;

@end
