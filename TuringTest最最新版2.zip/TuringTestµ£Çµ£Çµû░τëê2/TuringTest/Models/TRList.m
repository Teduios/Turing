//
//  TRList.m
//  Day08_1_Message
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TRList.h"

@implementation TRList
//+ (NSArray *)lists:(NSDictionary*)dict {
//    NSArray *listsArray = dict[@"list"];
//    NSMutableArray *listsMutableArray = [NSMutableArray array];
//    
//    for (NSDictionary *listDic in listsArray) {
//        TRList *list = [TRList new];
//        [list setValuesForKeysWithDictionary:listDic];
//        [listsMutableArray addObject:list];
//    }
//    return [listsMutableArray copy];
//}

@end
