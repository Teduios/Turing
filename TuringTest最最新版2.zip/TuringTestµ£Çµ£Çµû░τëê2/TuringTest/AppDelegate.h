//
//  AppDelegate.h
//  TuringTest
//
//  Created by Turing on 15/8/24.
//  Copyright (c) 2015年 Turing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

