//
//  KeyString.h
//  TuringTest
//
//  Created by Zeng Haitao on 15/9/7.
//  Copyright (c) 2015年 Zeng Haitao. All rights reserved.
//

#ifndef TuringTest_KeyString_h
#define TuringTest_KeyString_h

#define BaiduAPIKey @"rGjZi3g3RmjqQblC95abdoMy"
#define BaiduSecretKey @"NPXtVWQIkRkgBmT3Ng5eOM6oXyPFqZ2v"
#define TuringAPIKey @"c7492b8f210dc5cdbf76b3bde66a7c32"

#endif
