//
//  TRFrontViewController.m
//  TuringTest
//
//  Created by 刘小姐 on 15/11/18.
//  Copyright © 2015年 Zeng Haitao. All rights reserved.
//

#import "TRFrontViewController.h"
#import "TRMainViewController.h"

#import "UIImageView+UIActivityIndicatorForSDWebImage.h"


@interface TRFrontViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@property (weak, nonatomic) IBOutlet UITextField *textField;
@property(nonatomic,strong)UIImage*image;
@property (weak, nonatomic) IBOutlet UILabel *label;

@end

@implementation TRFrontViewController

- (IBAction)textField:(UITextField *)sender {
       NSString* string = [NSString stringWithFormat:@"https://robohash.org/%@.png",sender.text];
    string = [string stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    NSURL *url = [NSURL URLWithString:string];
    [self.imageView setImageWithURL:url completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        self.label.hidden = YES;
        self.image = [UIImage new];
        self.image = image;
    } usingActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
  }
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Pattern"]];
   
    self.imageView.layer.cornerRadius = 20;
    self.imageView.layer.masksToBounds = YES;
 
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
     
     if (self.imageView.image == nil) {
         UIAlertController*alert =   [UIAlertController alertControllerWithTitle:@"输入文字" message:@"请给机器人一个头像T_T" preferredStyle:1];
         UIAlertAction*okAction = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:nil];
         [alert addAction:okAction];
         [self presentViewController:alert animated:YES completion:nil];
     }else{
         TRMainViewController*mainVC = segue.destinationViewController;
         mainVC.imageLast = self.image;
        // [self.navigationController pushViewController:mainVC animated:YES];
     }

 }


@end
