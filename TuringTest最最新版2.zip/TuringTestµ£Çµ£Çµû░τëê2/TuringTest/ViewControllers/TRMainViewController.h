//
//  ViewController.h
//  Day08_1_Message
//
//  Created by tarena on 15/10/8.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRMainViewController : UIViewController
@property(nonatomic,strong)UIImage*imageLast;

@end

